module github.com/friskipradana/panel-desktop-ui

go 1.22
