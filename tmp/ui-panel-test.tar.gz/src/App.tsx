import { useEffect, useState } from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Taskbar } from '@/components/taskbar/Taskbar'
import { Dock } from '@/components/dock/Dock'
import { Window } from '@/components/desktop/Window'
import { AppsWindow } from '@/components/windows/AppsWindow'
import { SystemWindow } from '@/components/windows/SystemWindow'
import { LoginScreen } from '@/components/windows/LoginScreen'
import { useWindowStore } from '@/store/windowStore'
import { getMe } from '@/api/agent'
import type { WindowId } from '@/types'
import { DebugPanel } from '@/components/debug/DebugPanel'
import { DebugGrid } from './components/debug/DebugGrid'

const WINDOW_CONTENT: Partial<Record<WindowId, React.ReactNode>> = {
  apps: <AppsWindow />,
  system: <SystemWindow />,
  portainer: (
    <div className="flex flex-col items-center justify-center gap-3 h-32">
      <span className="text-4xl">🐋</span>
      <a
        href="http://localhost:9000"
        target="_blank"
        rel="noreferrer"
        className="text-sm font-medium px-4 py-2 rounded-lg text-white"
        style={{ background: 'var(--accent)' }}
      >
        Buka Portainer →
      </a>
    </div>
  ),
  terminal: (
    <div className="rounded-lg p-4 font-mono text-xs leading-relaxed" style={{ background: '#1a1108', color: '#c8f59a' }}>
      <span style={{ color: '#f76707' }}>root@ui-panel</span>
      <span style={{ color: 'white' }}>:</span>
      <span style={{ color: '#c8f59a' }}>~</span>$ systemctl status ui-panel
      <br />
      <span style={{ color: '#888' }}>● ui-panel.service - active (running)</span>
      <br />
      <span style={{ color: '#888' }}>● docker.service - active (running)</span>
      <br />
      <span style={{ color: '#888' }}>● portainer - listening on :9000</span>
      <br />
      <br />
      <span style={{ color: '#f76707' }}>root@ui-panel</span>
      <span style={{ color: 'white' }}>:</span>
      <span style={{ color: '#c8f59a' }}>~</span>$ <span className="animate-pulse">█</span>
      <p className="mt-3 text-xs" style={{ color: '#555' }}>
        Terminal interaktif akan lebih cocok jika nanti kita sambungkan ke backend exec/ssh gateway.
      </p>
    </div>
  ),
  docs: (
    <div className="flex flex-col gap-2">
      {[
        { icon: '🚀', title: 'Bootstrap install', cmd: 'sudo bash installer/linux/install.sh' },
        { icon: '🧠', title: 'Agent health', cmd: 'curl http://127.0.0.1:8787/healthz' },
        { icon: '📦', title: 'Portainer logs', cmd: 'docker logs -f ui-panel-portainer' },
        { icon: '🪵', title: 'Agent logs', cmd: 'journalctl -u ui-panel -f' },
        { icon: '🔁', title: 'Restart panel', cmd: 'sudo systemctl restart ui-panel' },
        { icon: '🧹', title: 'Uninstall', cmd: 'sudo bash installer/linux/uninstall.sh' },
      ].map((d) => (
        <div key={d.title} className="rounded-lg p-3" style={{ background: 'rgba(0,0,0,0.04)', border: '0.5px solid rgba(0,0,0,0.07)' }}>
          <p className="text-xs font-semibold mb-1" style={{ color: 'var(--sand-600)' }}>{d.icon} {d.title}</p>
          <code className="text-xs" style={{ color: 'var(--sand-400)', fontFamily: 'monospace' }}>{d.cmd}</code>
        </div>
      ))}
    </div>
  ),
  changelog: (
    <div>
      {[
        { v: 'v0.2.0', d: 'Hari ini', items: ['Go panel agent bootstrap', 'Linux installer shell', 'Frontend login screen ke agent'] },
        { v: 'v0.1.0', d: 'Hari ini', items: ['Desktop UI React + Vite + TS', 'Zustand window manager', 'Portainer integration awal'] },
      ].map((c) => (
        <div key={c.v} className="mb-5">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-semibold text-white px-2 py-0.5 rounded-md" style={{ background: 'var(--accent)' }}>
              {c.v}
            </span>
            <span className="text-xs" style={{ color: 'var(--sand-400)' }}>{c.d}</span>
          </div>
          {c.items.map((i) => (
            <p key={i} className="text-xs pl-2 leading-relaxed" style={{ color: 'var(--sand-500)' }}>• {i}</p>
          ))}
        </div>
      ))}
    </div>
  ),
  settings: <SystemWindow />,
  trash: (
    <div className="flex flex-col items-center justify-center h-24 gap-2" style={{ color: 'var(--sand-400)' }}>
      <span className="text-4xl">🗑️</span>
      <span className="text-sm">Trash is empty</span>
    </div>
  ),
}

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 5_000 } },
})

function Desktop() {
  const { windows } = useWindowStore()

  return (
    <div className="wallpaper w-screen h-screen relative overflow-hidden">
      <Taskbar />
      <div className="absolute inset-0">
        {windows.map((win) => (
          <Window key={win.id} win={win}>
            {WINDOW_CONTENT[win.id] ?? (
              <p className="text-sm" style={{ color: 'var(--sand-400)' }}>No content.</p>
            )}
          </Window>
        ))}
      </div>
      <Dock />
    </div>
  )
}

function AppShell() {
  const [checkingSession, setCheckingSession] = useState(true)
  const [authenticated, setAuthenticated] = useState(false)

  useEffect(() => {
    let cancelled = false

    getMe()
      .then(() => {
        if (!cancelled) setAuthenticated(true)
      })
      .catch(() => {
        if (!cancelled) setAuthenticated(false)
      })
      .finally(() => {
        if (!cancelled) setCheckingSession(false)
      })

    return () => {
      cancelled = true
    }
  }, [])

  if (checkingSession) {
    return (
      <div className="min-h-screen grid place-items-center text-white login-shell">
        <div className="glass-panel rounded-[28px] px-8 py-6 text-sm text-white/78">
          Mengecek session bootstrap agent...
        </div>
      </div>
    )
  }

  if (!authenticated) {
    return <LoginScreen onLoginSuccess={() => setAuthenticated(true)} />
  }

  return (
    <>
      <Desktop />
      <DebugPanel />
      <DebugGrid />
    </>
  )
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppShell />
    </QueryClientProvider>
  )
}
