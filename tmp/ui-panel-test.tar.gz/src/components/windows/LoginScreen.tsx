import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  LoaderCircle,
  ShieldCheck,
  Sparkles,
  Wrench,
} from 'lucide-react'
import { getBootstrapStatus, loginAgent } from '@/api/agent'

interface Props {
  onLoginSuccess: () => void
}

const HIGHLIGHTS = [
  {
    title: 'Bootstrap auth',
    desc: 'Agent backend aktif dan siap menerima login awal.',
  },
  {
    title: 'Docker runtime',
    desc: 'Host disiapkan untuk app container dan service panel.',
  },
  {
    title: 'Portainer bridge',
    desc: 'Tetap tersedia sebagai integrasi container pendukung.',
  },
]

export function LoginScreen({ onLoginSuccess }: Props) {
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('')

  const bootstrapQuery = useQuery({
    queryKey: ['bootstrap-status'],
    queryFn: getBootstrapStatus,
    retry: 1,
    refetchInterval: 15_000,
  })

  const loginMutation = useMutation({
    mutationFn: () => loginAgent(username.trim(), password),
    onSuccess: () => {
      setPassword('')
      onLoginSuccess()
    },
  })

  const bootstrap = bootstrapQuery.data
  const isAgentReady = !!bootstrap && !bootstrapQuery.isError

  return (
    <main className="login-page" id="panel-login-screen">
      <div className="login-shell absolute inset-0" />
      <div className="login-noise absolute inset-0 opacity-50" />
      <div className="login-grid relative z-10">
        <section className="login-hero glass-panel">
          <div className="login-badge">
            <Sparkles size={14} />
            Linux-first control panel
          </div>

          <div className="login-hero-copy">
            <p className="login-kicker">Bootstrap access</p>
            <h1>
              Kelola server, container, dan proses instalasi dari satu panel yang terasa premium.
            </h1>
            <p className="login-lead">
              Login menggunakan credential bootstrap dari installer. Setelah masuk, panel akan menampilkan
              health host, status Docker, dan integrasi Portainer dari backend agent.
            </p>
          </div>

          <div className="login-highlight-grid">
            {HIGHLIGHTS.map((item) => (
              <article key={item.title} className="login-highlight-card">
                <div className="login-highlight-icon">
                  <CheckCircle2 size={14} />
                </div>
                <div>
                  <p className="login-highlight-title">{item.title}</p>
                  <p className="login-highlight-desc">{item.desc}</p>
                </div>
              </article>
            ))}
          </div>

          <div className="login-bottom-note">
            <Wrench size={18} className="shrink-0 text-cyan-200" />
            <p>
              Tahap berikutnya kita lanjutkan ke kontrol Docker, onboarding app template, dan testing instalasi
              langsung di server Linux target.
            </p>
          </div>
        </section>

        <section className="login-auth glass-panel">
          <div className="login-auth-header">
            <div className={`status-orb ${isAgentReady ? '' : 'status-orb--warn'}`} />
            <div>
              <p className="login-panel-label">Agent status</p>
              <h2>{bootstrap?.hostname ?? 'Menunggu respons agent...'}</h2>
            </div>
          </div>

          <div className="login-status-card">
            <StatusRow label="Installed" value={bootstrap ? (bootstrap.installed ? 'Yes' : 'No') : '...'} />
            <StatusRow label="Channel" value={bootstrap?.channel ?? '...'} />
            <StatusRow label="Bind address" value={bootstrap?.bindAddr ?? '...'} />
            <StatusRow label="Portainer" value={bootstrap?.portainerUrl ?? '...'} />
          </div>

          <form
            className="login-form"
            onSubmit={(e) => {
              e.preventDefault()
              loginMutation.mutate()
            }}
          >
            <label className="block">
              <span className="login-field-label">Username</span>
              <input
                id="panel-login-username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="auth-input"
                placeholder="admin"
                autoComplete="username"
              />
            </label>

            <label className="block">
              <span className="login-field-label">Password</span>
              <input
                id="panel-login-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="auth-input"
                placeholder="Masukkan password bootstrap"
                autoComplete="current-password"
              />
            </label>

            {(loginMutation.isError || bootstrapQuery.isError) && (
              <div className="login-alert">
                <AlertCircle size={16} className="mt-0.5 shrink-0" />
                <span>
                  {loginMutation.isError
                    ? 'Login gagal. Cek kembali username dan password bootstrap.'
                    : 'Agent belum merespons. Pastikan ui-panel-agent sudah berjalan.'}
                </span>
              </div>
            )}

            <button id="panel-login-submit" type="submit" className="auth-submit" disabled={loginMutation.isPending}>
              {loginMutation.isPending ? <LoaderCircle size={16} className="animate-spin" /> : <ShieldCheck size={16} />}
              <span>{loginMutation.isPending ? 'Signing in...' : 'Masuk ke panel'}</span>
              <ArrowRight size={16} />
            </button>
          </form>
        </section>
      </div>
    </main>
  )
}

function StatusRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="login-status-row">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}
