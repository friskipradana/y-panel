import { useQuery } from '@tanstack/react-query'
import { Activity, CheckCircle2, HardDriveDownload, ServerCrash, ShieldAlert } from 'lucide-react'
import { getSystemSummary } from '@/api/agent'

function HealthPill({ ok, label }: { ok: boolean; label: string }) {
  return (
    <div
      className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium"
      style={{
        background: ok ? 'rgba(52, 211, 153, 0.14)' : 'rgba(248, 113, 113, 0.14)',
        color: ok ? '#10b981' : '#ef4444',
      }}
    >
      {ok ? <CheckCircle2 size={14} /> : <ShieldAlert size={14} />}
      {label}
    </div>
  )
}

export function SystemWindow() {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['agent-system-summary'],
    queryFn: getSystemSummary,
    retry: 1,
    refetchInterval: 10_000,
  })

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-40 gap-3 text-sm" style={{ color: 'var(--sand-400)' }}>
        <Activity size={16} className="animate-pulse" />
        Mengambil health runtime dari ui-panel-agent...
      </div>
    )
  }

  if (isError || !data) {
    return (
      <div className="rounded-2xl p-4 text-sm" style={{ background: '#ffebee', color: '#b91c1c' }}>
        <div className="flex items-center gap-2 font-semibold mb-2">
          <ServerCrash size={16} />
          Gagal memuat system summary
        </div>
        <p className="opacity-80">Pastikan kamu sudah login dan service ui-panel-agent berjalan normal.</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-3xl p-5 text-white" style={{ background: 'linear-gradient(135deg, #111827 0%, #1f2937 60%, #0f172a 100%)' }}>
        <p className="text-xs uppercase tracking-[0.22em] text-white/45">System runtime</p>
        <h2 className="mt-3 text-2xl font-semibold tracking-[-0.03em]">{data.hostname}</h2>
        <p className="mt-2 text-sm text-white/65">Live status dari backend agent yang dipasang oleh installer Linux.</p>

        <div className="mt-5 flex flex-wrap gap-2">
          <HealthPill ok={data.dockerInstalled} label={data.dockerInstalled ? 'Docker installed' : 'Docker missing'} />
          <HealthPill ok={data.dockerReachable} label={data.dockerReachable ? 'Docker reachable' : 'Docker unreachable'} />
          <HealthPill ok={data.portainerReachable} label={data.portainerReachable ? 'Portainer online' : 'Portainer offline'} />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <article className="rounded-2xl border p-4" style={{ borderColor: 'rgba(0,0,0,0.08)', background: 'rgba(255,255,255,0.85)' }}>
          <div className="flex items-center gap-2 mb-3" style={{ color: 'var(--sand-600)' }}>
            <HardDriveDownload size={16} />
            <span className="font-semibold">Storage & state</span>
          </div>
          <p className="text-xs mb-1" style={{ color: 'var(--sand-400)' }}>State directory</p>
          <code className="text-xs break-all" style={{ color: '#111827' }}>{data.stateDir}</code>
        </article>

        <article className="rounded-2xl border p-4" style={{ borderColor: 'rgba(0,0,0,0.08)', background: 'rgba(255,255,255,0.85)' }}>
          <div className="flex items-center gap-2 mb-3" style={{ color: 'var(--sand-600)' }}>
            <Activity size={16} />
            <span className="font-semibold">Integration</span>
          </div>
          <p className="text-xs mb-1" style={{ color: 'var(--sand-400)' }}>Portainer endpoint</p>
          <code className="text-xs break-all" style={{ color: '#111827' }}>{data.portainerUrl}</code>
        </article>
      </div>
    </div>
  )
}
