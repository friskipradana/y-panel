import axios from 'axios'

export interface BootstrapStatus {
  installed: boolean
  channel: string
  bindAddr: string
  portainerUrl: string
  hostname: string
}

export interface AuthMe {
  username: string
  role: string
}

export interface SystemSummary {
  hostname: string
  dockerInstalled: boolean
  dockerReachable: boolean
  portainerReachable: boolean
  portainerUrl: string
  stateDir: string
}

const agentApi = axios.create({
  baseURL: '/agent',
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
})

export const getBootstrapStatus = () =>
  agentApi.get<BootstrapStatus>('/api/v1/bootstrap/status').then((r) => r.data)

export const loginAgent = (username: string, password: string) =>
  agentApi.post<{ ok: boolean; username: string }>('/api/v1/auth/login', { username, password }).then((r) => r.data)

export const getMe = () =>
  agentApi.get<AuthMe>('/api/v1/me').then((r) => r.data)

export const getSystemSummary = () =>
  agentApi.get<SystemSummary>('/api/v1/system/summary').then((r) => r.data)
