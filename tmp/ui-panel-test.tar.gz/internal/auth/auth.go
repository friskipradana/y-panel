package auth

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"errors"
	"sync"
)

type Manager struct {
	username string
	password string

	mu       sync.RWMutex
	sessions map[string]string
}

func NewManager(username, password string) *Manager {
	return &Manager{
		username: username,
		password: password,
		sessions: make(map[string]string),
	}
}

func (m *Manager) Login(username, password string) (string, error) {
	if subtle.ConstantTimeCompare([]byte(username), []byte(m.username)) != 1 {
		return "", errors.New("invalid credentials")
	}
	if subtle.ConstantTimeCompare([]byte(password), []byte(m.password)) != 1 {
		return "", errors.New("invalid credentials")
	}

	token, err := randomToken(32)
	if err != nil {
		return "", err
	}

	m.mu.Lock()
	m.sessions[token] = username
	m.mu.Unlock()

	return token, nil
}

func (m *Manager) Validate(token string) (string, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	username, ok := m.sessions[token]
	return username, ok
}

func randomToken(length int) (string, error) {
	buf := make([]byte, length)
	if _, err := rand.Read(buf); err != nil {
		return "", err
	}
	return hex.EncodeToString(buf), nil
}
