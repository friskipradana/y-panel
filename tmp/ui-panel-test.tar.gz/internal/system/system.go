package system

import (
	"net/http"
	"os"
	"os/exec"
	"time"
)

type Summary struct {
	Hostname          string `json:"hostname"`
	DockerInstalled   bool   `json:"dockerInstalled"`
	DockerReachable   bool   `json:"dockerReachable"`
	PortainerReachable bool  `json:"portainerReachable"`
}

func Inspect(portainerURL string) Summary {
	hostname, _ := os.Hostname()
	return Summary{
		Hostname:           hostname,
		DockerInstalled:    hasCommand("docker"),
		DockerReachable:    dockerReachable(),
		PortainerReachable: urlReachable(portainerURL + "/api/status"),
	}
}

func hasCommand(name string) bool {
	_, err := exec.LookPath(name)
	return err == nil
}

func dockerReachable() bool {
	if !hasCommand("docker") {
		return false
	}
	cmd := exec.Command("docker", "info")
	return cmd.Run() == nil
}

func urlReachable(url string) bool {
	client := http.Client{Timeout: 3 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode >= 200 && resp.StatusCode < 500
}
